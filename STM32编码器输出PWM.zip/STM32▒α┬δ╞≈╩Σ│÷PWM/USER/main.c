#include "stm32f10x.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "string.h"
#include "pwm.h" 
#include "oled.h"
#include "exti.h" 
#include "key.h"
#include "adc.h"

u16 freqnum=1;
float  puty=0.5;
u8 flag=1; 
u8 card [20];
extern __IO uint16_t ADC_ConvertedValue;
float ADC_ConvertedValueLocal=0;

int main(void)
 {	
	u8 adcx;
	u8 qtis=0;
	float temp;
  delay_init();	    	 //��ʱ������ʼ��	  
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�����ж����ȼ�����Ϊ��2��2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(921600);	 	//���ڳ�ʼ��Ϊ115200	
	EXTIX_Init();		//�ⲿ�жϳ�ʼ�� 	 
 	TIM2_PWM_Init(freqnum,(10000/freqnum)*puty );	
	Adc_Init();		  		//ADC��ʼ��
  OLED_Init();
	OLED_Clear(); 
    OLED_ShowCHinese(0,2,2); 
		OLED_ShowCHinese(18,2,3);
	  OLED_ShowCHinese(36,2,4);
	  OLED_ShowString(54,2,":",16);
	  OLED_ShowString(108,2,"%",16);

	 	OLED_ShowCHinese(0,4,8); 
		OLED_ShowCHinese(16,4,9); 
		OLED_ShowCHinese(32,4,10); 
	  OLED_ShowString(48,4,":",16);
	 
		OLED_ShowCHinese(36,0,5); 
		OLED_ShowCHinese(52,0,6); 
	  OLED_ShowCHinese(68,0,7);		
  while(1)
	{	 
		u8 t;
		qtis=qtis+GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_2);
		if(qtis!=0)	
		{
			puty=0.2;
			qtis=0;
		}
	  OLED_ShowNum(75,2,puty*100,2,16);
		adcx=Get_Adc_Average(ADC_Channel_1,10);
//		temp=(float)adcx*(3.3/4096);
//		adcx=temp;		
		OLED_ShowNum(80,4,adcx,2,16);
	}
 }

